//
//  ViewController.swift
//  Solve Alert Action Problem
//
//  Created by Abhishek Verma on 31/03/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var alert = UIAlertController()
    var a = UIAlertAction()
    var b = UIAlertAction()
    var c = UIAlertAction()
    var cancel = UIAlertAction()
    var condition = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        condition = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func Menu(_ sender: Any) {
        self.showalert()
    }
    func showalert()
    {
        alert = UIAlertController(title: "Swifthub", message: nil, preferredStyle: .actionSheet)
        a = UIAlertAction(title: "A", style: .default) { (a) in
            
        }
        b = UIAlertAction(title: "B", style: .default) { (b) in
            if self.condition == true
            {
                self.condition = false
                self.showalert()
            }
            else
            {
                self.condition = true
                self.showalert()
            }
        }
        c = UIAlertAction(title: "C", style: .default) { (c) in
            
        }
        cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        if condition == true
        {
            self.a.isEnabled = true
            self.c.isEnabled = true
        }
        else
        {
            a.isEnabled = false
            c.isEnabled = false
        }

        alert.addAction(a)
        alert.addAction(b)
        alert.addAction(c)
        self.present(alert, animated: true, completion: nil)
    }
    
}

